package io.github.devhyper.openvideoeditor.videoeditor

import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.RgbMatrix

/** GPU color looks implemented as 4x4 RGB transforms in Media3's linear RGB working space. */
@UnstableApi
object ColorLooks {
    private fun matrix(values: FloatArray): Effect = object : RgbMatrix {
        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = values
    }

    // Matrix layout follows Media3's RgbMatrix convention (column-major 4x4).
    val cinematicTeal: Effect = matrix(floatArrayOf(
        0.88f, 0.04f, 0.02f, 0f,
        0.03f, 0.92f, 0.04f, 0f,
        0.02f, 0.08f, 0.98f, 0f,
        0.015f, 0.012f, 0.018f, 1f
    ))
    val warmFilm: Effect = matrix(floatArrayOf(
        1.04f, 0.02f, 0f, 0f,
        0.015f, 1.00f, 0.01f, 0f,
        0f, 0.01f, 0.91f, 0f,
        0.018f, 0.010f, 0.002f, 1f
    ))
    val bleachBypass: Effect = matrix(floatArrayOf(
        0.92f, 0.06f, 0.04f, 0f,
        0.06f, 0.92f, 0.04f, 0f,
        0.04f, 0.06f, 0.90f, 0f,
        0.015f, 0.015f, 0.015f, 1f
    ))
    val silverRed: Effect = matrix(floatArrayOf(
        0.30f, 0.30f, 0.30f, 0f,
        0.28f, 0.29f, 0.28f, 0f,
        0.22f, 0.22f, 0.23f, 0f,
        0.010f, 0.004f, 0.004f, 1f
    ))
    val fadedPrint: Effect = matrix(floatArrayOf(
        0.94f, 0.03f, 0.02f, 0f,
        0.02f, 0.93f, 0.03f, 0f,
        0.02f, 0.04f, 0.90f, 0f,
        0.035f, 0.025f, 0.018f, 1f
    ))
    val industrial: Effect = matrix(floatArrayOf(
        0.96f, 0.02f, 0.02f, 0f,
        0.02f, 0.91f, 0.03f, 0f,
        0.02f, 0.03f, 0.88f, 0f,
        0.006f, 0.008f, 0.010f, 1f
    ))
}
