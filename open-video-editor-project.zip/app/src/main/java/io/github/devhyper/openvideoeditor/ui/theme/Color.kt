package io.github.devhyper.openvideoeditor.ui.theme

import androidx.compose.ui.graphics.Color

val AccentOrange = Color(0xFFFF7A18)
val AccentOrangeLight = Color(0xFFFFA45B)
val WorkspaceBlack = Color(0xFF08090B)
val PanelDark = Color(0xFF141619)
val BorderDark = Color(0xFF292D32)
val TextPrimaryDark = Color(0xFFF4F5F6)
val TextSecondaryDark = Color(0xFF9BA1A8)

val Purple80 = AccentOrangeLight
val PurpleGrey80 = Color(0xFFB8A79A)
val Pink80 = Color(0xFFFFC09A)
val Purple40 = AccentOrange
val PurpleGrey40 = Color(0xFF76513A)
val Pink40 = Color(0xFFB95B19)
