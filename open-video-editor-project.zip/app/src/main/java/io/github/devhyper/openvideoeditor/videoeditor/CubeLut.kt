package io.github.devhyper.openvideoeditor.videoeditor

import android.graphics.Color
import androidx.media3.common.util.UnstableApi
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import kotlin.math.roundToInt

/** Parses the common Iridas/Adobe .cube 3D-LUT text format. */
@UnstableApi
object CubeLut {
    fun parse(input: InputStream): Array<Array<IntArray>> {
        var size = 0
        val values = ArrayList<FloatArray>()
        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
            reader.forEachLine { raw ->
                val line = raw.substringBefore('#').trim()
                if (line.isEmpty() || line.startsWith("TITLE") || line.startsWith("DOMAIN_MIN") || line.startsWith("DOMAIN_MAX")) return@forEachLine
                require(!line.startsWith("LUT_1D_SIZE")) { "1D LUT is not supported; use a 3D .cube LUT." }
                if (line.startsWith("LUT_3D_SIZE")) {
                    size = line.substringAfter("LUT_3D_SIZE").trim().toIntOrNull() ?: 0
                    require(size in 2..64) { "Unsupported LUT_3D_SIZE: $size" }
                    return@forEachLine
                }
                val components = line.split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
                if (components.size >= 3) values.add(floatArrayOf(components[0], components[1], components[2]))
            }
        }
        require(size >= 2) { "LUT_3D_SIZE is missing" }
        require(values.size == size * size * size) { "Expected ${size * size * size} LUT entries, found ${values.size}" }
        val cube = Array(size) { Array(size) { IntArray(size) } }
        values.forEachIndexed { index, rgb ->
            // .cube ordering: red changes fastest, then green, then blue.
            val r = index % size
            val g = (index / size) % size
            val b = index / (size * size)
            val red = (rgb[0].coerceIn(0f, 1f) * 255f).roundToInt()
            val green = (rgb[1].coerceIn(0f, 1f) * 255f).roundToInt()
            val blue = (rgb[2].coerceIn(0f, 1f) * 255f).roundToInt()
            cube[r][g][b] = Color.rgb(red, green, blue)
        }
        return cube
    }
    fun blendWithIdentity(cube: Array<Array<IntArray>>, intensity: Float): Array<Array<IntArray>> {
        val amount = intensity.coerceIn(0f, 1f)
        val size = cube.size
        return Array(size) { r -> Array(size) { g -> IntArray(size) { b ->
            val source = cube[r][g][b]
            val identityR = (r * 255f / (size - 1)).roundToInt()
            val identityG = (g * 255f / (size - 1)).roundToInt()
            val identityB = (b * 255f / (size - 1)).roundToInt()
            val red = (identityR + (Color.red(source) - identityR) * amount).roundToInt()
            val green = (identityG + (Color.green(source) - identityG) * amount).roundToInt()
            val blue = (identityB + (Color.blue(source) - identityB) * amount).roundToInt()
            Color.rgb(red, green, blue)
        } } }
    }

}
